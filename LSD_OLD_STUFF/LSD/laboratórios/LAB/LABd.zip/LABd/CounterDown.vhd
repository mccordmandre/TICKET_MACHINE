library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
use IEEE.NUMERIC_STD.ALL;

entity CounterDown is
    port (
        CLK     : in std_logic;
        PL      : in std_logic;
        CE      : in std_logic;
        dataIn  : in std_logic_vector(3 downto 0);
        Q       : out std_logic_vector(3 downto 0)
    );
end CounterDown;

architecture Behavioral of CounterDown is
    signal count_reg : std_logic_vector(3 downto 0) := (others => '0');
begin

    process(CLK)
    begin
        if rising_edge(CLK) then
            if PL = '1' then
                count_reg <= dataIn;
            elsif CE = '1' then
                if count_reg = "0000" then
                    count_reg <= "1111"; -- Reinicia em 15 após atingir 0
                else
                    count_reg <= std_logic_vector(unsigned(count_reg) - 1);
                end if;
            end if;
        end if;
    end process;

    Q <= count_reg;

end Behavioral;
