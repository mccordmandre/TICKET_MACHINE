library ieee;
use ieee.std_logic_1164.all;

entity lm_MUX4 is
  port (
    A, B, C, D : in  std_logic_vector(4 downto 0);
    -- Selector de 1 bit
    S : in std_logic_vector (1 downto 0);
    Y : out std_logic_vector(3 downto 0);
    Cy : out std_logic
  );
end entity;

architecture behavioral of lm_MUX4 is

begin

  Y <= A(3 downto 0) when S(0) = '0' and S(1) = '0' else
       B(3 downto 0) when S(0) = '0' and S(1) = '1' else
       C(3 downto 0) when S(0) = '1' and S(1) = '0' else  
       D(3 downto 0) when S(0) = '1' and S(1) = '1';

  Cy <= A(4) when S = "00" else
        B(4) when S = "01" else
        C(4) when S = "10" else  
        D(4) when S = "11";
end architecture;

