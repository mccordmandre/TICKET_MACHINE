library ieee;
use ieee.std_logic_1164.all;

entity alu_decoder is
	port(
		OP0, OP1, OP2: in std_logic;
		OPA, OPB, OPC, OPD, OPE, OPF: out std_logic
	);
	
end entity;

architecture behavioral of alu_decoder is

begin

	OPA <= (not(OP0) and OP1 and not(OP2)) OR ( not(OP0) and OP1 and OP2);
	OPB <= (not(OP0) and not(OP1) and OP2) OR ( not(OP2) and OP1 and OP2);
	OPC <= OP0;
	OPD <= (OP0 and not(OP1) and not(OP2)) OR ( OP0 and not(OP1) and OP2);
	OPE <= (OP0 and not(OP1) and OP2) OR ( OP0 and OP1 and not(OP2));
	OPF <= OP0;
	
end behavioral;





--library ieee;
--use ieee.std_logic_1164.all;
--
--entity decoder is
--    port(
--        OP0, OP1, OP2: in std_logic;
--        OPA, OPB, OPC, OPD, OPE, OPF: out std_logic
--    );
--end entity;
--
--architecture behavioral of decoder is
--begin
--    process(OP0, OP1, OP2)
--    begin
--        -- Initialize all outputs to '0'
--        OPA <= '0';
--        OPB <= '0';
--        OPC <= '0';
--        OPD <= '0';
--        OPE <= '0';
--        OPF <= '0';
--
--        -- Concatenate inputs to form a binary number
--        case (OP2 & OP1 & OP0) is
--            when "000" => 
--                OPA <= '1';
--            when "001" =>
--                OPB <= '1';
--            when "010" =>
--                OPC <= '1';
--            when "011" =>
--                OPD <= '1';
--            when "100" =>
--                OPE <= '1';
--            when "101" =>
--                OPF <= '1';
--            when others =>
--                null;
--        end case;
--    end process;
--end architecture;
